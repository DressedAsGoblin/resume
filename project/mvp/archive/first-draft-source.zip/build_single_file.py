"""Package the local draft as one offline HTML, including original project figures."""
from pathlib import Path
import base64,re

root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf8')
css=(root/'style.css').read_text(encoding='utf8')
data=(root/'projects-data.js').read_text(encoding='utf8')
depth=(root/'depth-data.js').read_text(encoding='utf8')
app=(root/'app.js').read_text(encoding='utf8')

def image(match):
    path=root/match[1]
    mime='image/png' if path.suffix.lower()=='.png' else 'image/jpeg'
    return '"src": "data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode('ascii')+'"'

data=re.sub(r'"src":\s*"(assets/[^\"]+)"',image,data)
depth=re.sub(r"src:\s*'(assets/[^']+)'",lambda m:'src: '+image(m).split(': ',1)[1],depth)
html=html.replace('<link rel="stylesheet" href="style.css">','<style>\n'+css+'\n</style>')
html=html.replace('<script src="projects-data.js"></script>','<script>\n'+data.replace('</script','<\\/script')+'\n</script>')
html=html.replace('<script src="depth-data.js"></script>','<script>\n'+depth.replace('</script','<\\/script')+'\n</script>')
html=html.replace('<script src="app.js"></script>','<script>\n'+app.replace('</script','<\\/script')+'\n</script>')
out=root.parent/'Мир проектов — MVP.html'
out.write_text(html,encoding='utf8')
assert 'src="app.js"' not in html and 'href="style.css"' not in html
assert html.count('data:image/png;base64,')==9
assert 'src="depth-data.js"' not in html
print(f'{out}\n{out.stat().st_size:,} bytes; 9 embedded images')
